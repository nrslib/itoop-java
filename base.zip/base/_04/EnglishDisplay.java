package base._04;

// EnglishDisplay クラスを定義しよう