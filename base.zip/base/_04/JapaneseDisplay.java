package base._04;

// JapaneseDisplay クラスを定義しよう