package base._06;

public interface Rule {
    int judge(int player, int cpu);
}
