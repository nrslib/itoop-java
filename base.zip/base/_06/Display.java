package base._06;

public interface Display {
    void show(int result);
}
