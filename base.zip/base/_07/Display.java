package base._07;

public interface Display {
    void show(int result);
}
