package base._07;

public interface Rule {
    int judge(int player, int cpu);
}
