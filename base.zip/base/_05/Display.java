package base._05;

public interface Display {
    void show(int result);
}
