package base._05;

public interface Rule {
    int judge(int player, int cpu);
}
