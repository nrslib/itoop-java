package base._01;

public class Program {
    public static void main(String[] args) {
        var program = new JankenProgram();
        program.play(1, 2);
    }
}
