package base._02;

// JankenGame クラスを定義しよう